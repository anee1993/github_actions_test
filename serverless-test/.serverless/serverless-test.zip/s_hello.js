
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'anirudh9393',
  applicationName: 'serverless-app',
  appUid: 'sF5Cn8Sr4dz9Kpy8VC',
  orgUid: 'e99a4929-7f0e-41e5-9628-4c353d3fb371',
  deploymentUid: '9b1a3247-5b4a-4a49-8496-d70263f8d4b9',
  serviceName: 'serverless-test',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-test-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}